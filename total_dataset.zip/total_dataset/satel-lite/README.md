# Satellite

Satellite is a domain that involves using one or more satellites to make observations, by collecting data and down-linking the data to a desired ground station.

The domain formalisation in this dataset is the [STRIPS version from IPC-3](http://ipc02.icaps-conference.org/CompoDomains/SatelliteStrips.pddl), and thus lacks the operator for sending the image. 