# Driver-Log

Driver-Log is a domain that consists of drivers that can walk between locations and trucks that can drive between locations. Walking from locations requires traversal of different paths. Trucks can be loaded with or unloaded of packages. Goals in this domain consists of transporting packages between locations.