# Zeno-Travel

Zeno-Travel is a domain where passengers can embark and disembark onto aircraft that can fly at two alternative speeds between locations.